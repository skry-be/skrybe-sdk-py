import os
import sys
import django

def main():
    print("Skrybe SDK Django package is installed and ready.")

if __name__ == "__main__":
    main()
